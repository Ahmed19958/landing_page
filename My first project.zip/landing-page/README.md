# Landing Page Project

## Table of Contents

1- i have creat 4 section at my project every section related with link of navbar dynamically 
2- created navbar with empaty ul list every anchor at this list while you click on it will scroll to the related section 
3- when every section is viwed on the page it will have an active automatic 
4- we have used (.getElementById && querySelectorAll) to can get element from HTML file .
5- we have used the below method also,

.getBoundingClientRect
.add
.remove
.addEventListener